#include "errors.h"

void print_error(status_code const error)
{
    const char * main_error = "Error occured: ";
    switch (error)
    {
        case command_line_arguments_error:
            printf("%s %s\n", main_error, errors_str[0]);
            break;
        case no_memory:
            printf("%s %s\n", main_error, errors_str[1]);
            break;
        case file_open_error:
            printf("%s %s\n", main_error, errors_str[2]);
            break;
        case invalid_function_argument:
            printf("%s %s\n", main_error, errors_str[3]);
            break;
        case invalid_base:
            printf("%s %s\n", main_error, errors_str[4]);
            break;
        case invalid_variable:
            printf("%s %s\n", main_error, errors_str[5]);
            break;
        case not_in_base:
            printf("%s %s\n", main_error, errors_str[6]);
            break;
        case cannot_find:
            printf("%s %s\n", main_error, errors_str[7]);
            break;
        case invalid_lexeme:
            printf("%s %s\n", main_error, errors_str[8]);
            break;
        case invalid_settings_file:
            printf("%s %s\n", main_error, errors_str[9]);
            break;

        default: break;
    }
}

status_code free_all(status_code error, int count, ...)
{
    va_list strings;
    va_start(strings, count);
    for (int i = 0; i < count; ++i)
    {
        char * string = va_arg(strings, char*);
        if (string)
        {
            free(string);
            string = NULL;
        }
    }
    va_end(strings);
    return error;
}