#ifndef _ERRORS_H_
#define _ERRORS_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdarg.h>

typedef enum
{
    OK,
    command_line_arguments_error,
    no_memory,
    fail,
    file_open_error,
    invalid_function_argument,
    invalid_base,
    invalid_variable,
    not_in_base,
    cannot_find,
    invalid_lexeme,
    invalid_settings_file

} status_code;

static const char* errors_str[] = 
{
        "Incorrect command line arguments.",
        "Memory error.",
        "File open error.",
        "Invalid function argument.",
        "Invalid base.",
        "Invalid variable.",
        "Variable is not in base.",
        "Variable is not initialized.",
        "Invalid lexeme.",
        "Invalid settings file."
};

void print_error(status_code const error);

status_code free_all(status_code error, int count, ...);

#endif