#include "operation_type.h"


status_code is_in_base(char * number, int base)
{
    if(number == NULL)
        return invalid_function_argument;
    if (base < 2 || base > 36) return invalid_base;
    int i = 0;
    while (number[i])
    {
        if (!isdigit(number[i]) && !isalpha(number[i])) return invalid_variable;
        else if (isdigit(number[i]) && number[i] - '0' >= base) return not_in_base;
        else if (isalpha(number[i]) && toupper(number[i]) - 'A' + 10 >= base) return not_in_base;
        ++i;
    }
    return OK;
}

int get_symbols_count(uint32_t number, int base)
{
    if(number == 0)
        return 1;
    int count = 0;
    while (number > 0)
    {
        number /= base;
        count++;
    }
    return count;
}

status_code is_new_operation(Current_settings* settings, char * string, operation * operation_name)
{
    if(string == NULL)
        return invalid_function_argument;
    for (int i = 0; i < OPERATIONS_COUNT; ++i)
    {
        if (strcmp(string, settings->operations_names[i]) == 0)
        {
            *operation_name = i;
            return OK;
        }
    }
    return fail;
}

status_code is_operation(char * string, operation * operation_name)
{
    if(string == NULL)
        return invalid_function_argument;
    for (int i = 0; i < OPERATIONS_COUNT; ++i)
    {
        if (strcmp(string, start_operations_names[i]) == 0)
        {
            *operation_name = i;
            return OK;
        }
    }
    return fail;
}

status_code is_variable(char * string)
{
    if (!string) return invalid_lexeme;
    if (strlen(string) == 0) return invalid_lexeme;
    if (isdigit(string[0])) return invalid_variable;
    operation smh = NOT;
    if(is_operation(string, &smh) == OK) return fail;
    for (int i = 0; string[i] != 0; ++i)
    {
        if (!isdigit(string[i]) && !isalpha(string[i]) && string[i] != '_') return invalid_variable;
    }
    return OK;
}

status_code is_debug(char * string)
{
    if(string == NULL)
        return fail;
    int count = 3;
    char * variations[] = {"--debug", "-d", "/debug"};
    for (int i = 0; i < count; ++i) if (!strcmp(variations[i], string)) return OK;
    return fail;
}